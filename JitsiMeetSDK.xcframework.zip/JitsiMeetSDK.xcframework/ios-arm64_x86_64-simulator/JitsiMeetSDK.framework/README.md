We are trying to keep these files relatively small. Use `resources/encode-sound.sh` to
encode a file in the same way (use --stereo if stereo is needed).
